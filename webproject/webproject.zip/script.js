document.querySelector('#close-edit').onclick = () =>{
   document.querySelector('.edit').style.display = 'none';
   window.location.href = 'admin.php';
};
