<header class="header">

   <div class="flex">

      <a href="#" class="logo">FOODS</a>

      <nav class="nav">
         <a href="products.php">View Products</a>
         <a href="logout.php" >logout</a>

      </nav>
      <a href="cart.php" class="cart">Cart <span>0</span> </a>



         </div>

      </header>
